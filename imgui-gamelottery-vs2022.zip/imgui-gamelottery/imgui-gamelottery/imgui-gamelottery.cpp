﻿// imgui-gamelottery.

#include <iostream>
#include <windows.h>
#include <filesystem>

#include <GL/glew.h>
#include <GL/GL.h>
#include <GL/GLU.h>
#include <GLFW/glfw3.h>

#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"

#if defined(_MSV_VER) && (_MSC_VER >= 1900) && !defined(IMGUI_DISABLE_WIN32_FUNCTIONS)
#pragma comment(lib,"legacy_stdio_definitons.lib")
#endif

#include "gamelottery_src/imgui_gamelottery.hpp"

using namespace std;

// USE NVIDIA GPU.
extern "C" {
    _declspec(dllexport)
        unsigned long NvOptimusEnablement = 0x00000001;
}

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
uint32_t LoadHandle(const char* image_file) {
    uint32_t texture_handle = NULL;
    int32_t _width = NULL, _height = NULL, _nrChannels = NULL;
    uint8_t* get_image_data = stbi_load(image_file, &_width, &_height, &_nrChannels, NULL);

    glGenTextures(1, &texture_handle);
    glBindTexture(GL_TEXTURE_2D, texture_handle);

    glTexImage2D(GL_TEXTURE_2D, NULL, _nrChannels, _width, _height, NULL, GL_RGBA, GL_UNSIGNED_BYTE, get_image_data);

    // opengl load texture init.
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // 生成mipmap级贴图.
    // glGenerateMipmap(GL_TEXTURE_2D); [err]

    glBindTexture(GL_TEXTURE_2D, NULL); // 解绑纹理.
    stbi_image_free(get_image_data);    // free.

    if ((texture_handle != NULL))
        cout << "Debug: Load image: " << image_file << endl;
    return texture_handle;
}

void GLFW_TEST_EVENTLOOP(ImGLO::ImGameLottery & LDobj) { // 循环.

    // start the ImGui frame.
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplGlfw_NewFrame();
    ImGui::NewFrame();
    {
        LDobj.RunTick([&LDobj]() {

            if (ImGui::Button("TEST")) {

                LDobj.StartLottery();
            }
            }
        );

    }
    // render imgui.
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

ImGLO::ImGameLottery* GLFW_TEST_EVENTINIT(GLFWwindow* WinObj) { // 初始化.

    ImGLO::ImGameLottery* LD_TEST_OBJ = new ImGLO::ImGameLottery(u8"测试抽奖", u8"查看奖池", u8"赢得的奖品");

    LD_TEST_OBJ->PushItem("Lv1 Low", 1, LoadHandle("test_mat_image/TestLv1.png"), u8"测试素材: Lv1");
    LD_TEST_OBJ->PushItem("Lv1 Low", 2, LoadHandle("test_mat_image/TestLv1.png"), u8"测试素材: Lv1");
    LD_TEST_OBJ->PushItem("Lv2 Medium", 3, LoadHandle("test_mat_image/TestLv2.png"), u8"测试素材: Lv2");
    LD_TEST_OBJ->PushItem("Lv1 Low", 4, LoadHandle("test_mat_image/TestLv1.png"), u8"测试素材: Lv1");
    LD_TEST_OBJ->PushItem("Lv1 Low", 5, LoadHandle("test_mat_image/TestLv1.png"), u8"测试素材: Lv1");
    LD_TEST_OBJ->PushItem("Lv2 Medium", 6, LoadHandle("test_mat_image/TestLv2.png"), u8"测试素材: Lv2");
    LD_TEST_OBJ->PushItem("Lv3 High", 7, LoadHandle("test_mat_image/TestLv3.png"), u8"测试素材: Lv3");

    LD_TEST_OBJ->PushItem("Lv1 Low", 8, LoadHandle("test_mat_image/TestLv1.png"), u8"测试素材: Lv1");
    LD_TEST_OBJ->PushItem("Lv1 Low", 9, LoadHandle("test_mat_image/TestLv1.png"), u8"测试素材: Lv1");
    LD_TEST_OBJ->PushItem("Lv2 Medium", 10, LoadHandle("test_mat_image/TestLv2.png"), u8"测试素材: Lv2");
    LD_TEST_OBJ->PushItem("Lv1 Low", 11, LoadHandle("test_mat_image/TestLv1.png"), u8"测试素材: Lv1");
    LD_TEST_OBJ->PushItem("Lv1 Low", 12, LoadHandle("test_mat_image/TestLv1.png"), u8"测试素材: Lv1");
    LD_TEST_OBJ->PushItem("Lv2 Medium", 13, LoadHandle("test_mat_image/TestLv2.png"), u8"测试素材: Lv2");
    LD_TEST_OBJ->PushItem("Lv3 High", 14, LoadHandle("test_mat_image/TestLv3.png"), u8"测试素材: Lv3");

    LD_TEST_OBJ->WindowBackgroundImg = LoadHandle("test_mat_image/PomeloStarLogo.png");

    LD_TEST_OBJ->InitPrizePool();

    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 7.2f);

    return LD_TEST_OBJ;
}

// ************************************************ GLFW Render Test ************************************************
// 推!
// 推!
// 推!
// 推!
// 推!
// 推!
// 推!
// 推!

static void GLFW_ErrorCallback(int error, const char* description) {
    // GlFW Callback ErrorPrint.
    fprintf(stderr, "[GLfwSystem]: GLFW Error %d: %s\n", error, description);
}

void oglwindow_eventloop(GLFWwindow* winobj) {
    int buffersize[2] = {};

    // Init.
    ImGLO::ImGameLottery* LDobj = GLFW_TEST_EVENTINIT(winobj);

    while (true) {
        glfwPollEvents();
        // glfwSetWindowShouldClose(_MainWinodwObj, PSA_TRUE);

        glfwGetFramebufferSize(winobj, &buffersize[0], &buffersize[1]);
        glViewport(0, 0, buffersize[0], buffersize[1]);

        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // main => oglwindow_eventloop => render_loop_event
        GLFW_TEST_EVENTLOOP(*LDobj);

        glfwMakeContextCurrent(winobj);
        glfwSwapBuffers(winobj);
    }
}

int main() {
    // glfw init create.
    glfwSetErrorCallback(GLFW_ErrorCallback);
    if (!glfwInit()) {
        cout << "GLFW ObjectInit Failed." << endl;
    }

    // OpenGL Window Config.
    {
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
        //glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_COMPAT_PROFILE); // 兼容模式.
        //glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);   // glfw.version 3.2+ [profile].
        //glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);             // glfw.version 3.0+ 
        glfwWindowHint(GLFW_RESIZABLE, GL_FALSE); // Fixed window size.
        glfwWindowHint(GLFW_SAMPLES, 4);          // 4x Samples MSAA.
    }

    // create window.
    GLFWmonitor* CreateFlag = {};
    GLFWwindow* WindowObject = {};

    WindowObject = glfwCreateWindow(
        1280, 768,
        "- GameLottery -", CreateFlag, nullptr
    );

    // create context.
    glfwMakeContextCurrent(WindowObject);
    // Enable Async. 开启垂直同步.
    glfwSwapInterval(1);

    {
        IMGUI_CHECKVERSION();

        // setup imgui context.
        ImGui::CreateContext();
        ImGuiIO& GuiIO = ImGui::GetIO();

        // 启用 键盘&手柄 交互.
        GuiIO.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard; // enable keyboard controls.
        GuiIO.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;  // enable gamepad controls.

        // setup imgui style.
        ImGui::StyleColorsDark();
        {
            ImGuiStyle* config_style = &ImGui::GetStyle();
            config_style->WindowRounding = 7.2f;
        }

        // init set fonts.
        auto SetFonts = ImGui::GetIO().Fonts;
        SetFonts->AddFontFromFileTTF
        (
            "external_library/guiimgui_library/imgui_fonts/MSYH_Bold.ttf",
            18.0f,
            NULL,
            SetFonts->GetGlyphRangesChineseFull()
        );

        // setup platform & renderer backends.
        ImGui_ImplGlfw_InitForOpenGL(WindowObject, true);
        ImGui_ImplOpenGL3_Init("#version 330 core");
    }

    // main => oglwindow_eventloop
    oglwindow_eventloop(WindowObject);

    // opengl free window.
    glfwDestroyWindow(WindowObject);
    glfwTerminate();
}