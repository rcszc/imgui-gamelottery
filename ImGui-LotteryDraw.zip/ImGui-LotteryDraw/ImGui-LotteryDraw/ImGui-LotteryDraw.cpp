﻿// ImGui-LotteryDraw. RCSZ

#include <iostream>
#include <windows.h>
//#include <filesystem>

#include <GL/glew.h>
#include <GL/GL.h>
#include <GL/GLU.h>
#include <GLFW/glfw3.h>

#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"

#if defined(_MSV_VER) && (_MSC_VER >= 1900) && !defined(IMGUI_DISABLE_WIN32_FUNCTIONS)
#pragma comment(lib,"legacy_stdio_definitons.lib")
#endif

#include "imgui_lottery_draw.h"

using namespace std;

// USE NVIDIA GPU.
extern "C" {
    _declspec(dllexport)
        unsigned long NvOptimusEnablement = 0x00000001;
}

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
uint32_t LoadHandle(const char* image_file) {
    uint32_t texture_handle = NULL;
    int32_t _width = NULL, _height = NULL, _nrChannels = NULL;
    uint8_t* get_image_data = stbi_load(image_file, &_width, &_height, &_nrChannels, NULL);

    glGenTextures(1, &texture_handle);
    glBindTexture(GL_TEXTURE_2D, texture_handle);

    glTexImage2D(GL_TEXTURE_2D, NULL, _nrChannels, _width, _height, NULL, GL_RGBA, GL_UNSIGNED_BYTE, get_image_data);

    // opengl load texture init.
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // 生成mipmap级贴图.
    // glGenerateMipmap(GL_TEXTURE_2D); [err]

    glBindTexture(GL_TEXTURE_2D, NULL); // 解绑纹理.
    stbi_image_free(get_image_data);    // free.

    if ((texture_handle != NULL))
        cout << "Debug: Load image: " << image_file << endl;
    return texture_handle;
}

void GLFW_TEST_EVENTLOOP(ImLD::ImLotteryDraw& LDobj) { // 循环.

    // start the ImGui frame.
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplGlfw_NewFrame();
    ImGui::NewFrame();
    {
        LDobj.ImLD_RunTick([&LDobj]() {
                
                if (ImGui::Button("TEST")) {

                    LDobj.ImLD_StartLottery();
                }
            }
        );

    }
    // render imgui.
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

ImLD::ImLotteryDraw* GLFW_TEST_EVENTINIT(GLFWwindow* WinObj) { // 初始化.

    ImLD::ImLotteryDraw* LD_TEST_OBJ = new ImLD::ImLotteryDraw(u8"测试抽奖", u8"查看奖池", u8"赢得的奖品");

    LD_TEST_OBJ->ImLD_PushItem("Black Dragon Armor", 1, LoadHandle("TestLDimg/TestPrize1.png"), u8"测试素材来源于: Pixel Gun 3D, 名称: Black Dragon Armor");
    LD_TEST_OBJ->ImLD_PushItem("Ultimatum", 2, LoadHandle("TestLDimg/TestPrize2.png"), u8"测试素材来源于: Pixel Gun 3D, 名称: Ultimatum");
    LD_TEST_OBJ->ImLD_PushItem("Eraser", 3, LoadHandle("TestLDimg/TestPrize3.png"), u8"测试素材来源于: Pixel Gun 3D, 名称: Eraser");
    LD_TEST_OBJ->ImLD_PushItem("Sparkling Hydra", 4, LoadHandle("TestLDimg/TestPrize4.png"), u8"测试素材来源于: Pixel Gun 3D, 名称: Sparkling Hydra");
    LD_TEST_OBJ->ImLD_PushItem("Abyssal Altar", 5, LoadHandle("TestLDimg/TestPrize5.png"), u8"测试素材来源于: Pixel Gun 3D, 名称: Abyssal Altar");
    LD_TEST_OBJ->ImLD_PushItem("Mordred", 6, LoadHandle("TestLDimg/TestPrize6.png"), u8"测试素材来源于: Pixel Gun 3D, 名称: Mordred");
    LD_TEST_OBJ->ImLD_PushItem("Checkmate", 7, LoadHandle("TestLDimg/TestPrize7.png"), u8"测试素材来源于: Pixel Gun 3D, 名称: Checkmate");
    LD_TEST_OBJ->ImLD_PushItem("Patrol Officer 747", 8, LoadHandle("TestLDimg/TestPrize8.png"), u8"测试素材来源于: Pixel Gun 3D, 名称: Patrol Officer 747");

    LD_TEST_OBJ->ImLD_Init();

    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 7.2f);

    return LD_TEST_OBJ;
}

// ************************************************ GLFW Render Test ************************************************
// 推!
// 推!
// 推!
// 推!
// 推!
// 推!
// 推!
// 推!

static void GLFW_ErrorCallback(int error, const char* description) {
    // GlFW Callback ErrorPrint.
    fprintf(stderr, "[GLfwSystem]: GLFW Error %d: %s\n", error, description);
}

void oglwindow_eventloop(GLFWwindow* winobj) {
    int buffersize[2] = {};

    // Init.
    ImLD::ImLotteryDraw* LDobj = GLFW_TEST_EVENTINIT(winobj);

    while (true) {
        glfwPollEvents();
        // glfwSetWindowShouldClose(_MainWinodwObj, PSA_TRUE);

        glfwGetFramebufferSize(winobj, &buffersize[0], &buffersize[1]);
        glViewport(0, 0, buffersize[0], buffersize[1]);

        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // main => oglwindow_eventloop => render_loop_event
        GLFW_TEST_EVENTLOOP(*LDobj);

        glfwMakeContextCurrent(winobj);
        glfwSwapBuffers(winobj);
    }
}

int main() {
    // glfw init create.
    glfwSetErrorCallback(GLFW_ErrorCallback);
    if (!glfwInit()) {
        cout << "GLFW ObjectInit Failed." << endl;
    }

    // OpenGL Window Config.
    {
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
        //glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_COMPAT_PROFILE); // 兼容模式.
        //glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);   // glfw.version 3.2+ [profile].
        //glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);             // glfw.version 3.0+ 
        glfwWindowHint(GLFW_RESIZABLE, GL_FALSE); // Fixed window size.
        glfwWindowHint(GLFW_SAMPLES, 4);          // 4x Samples MSAA.
    }

    // create window.
    GLFWmonitor* CreateFlag = {};
    GLFWwindow* WindowObject = {};

    WindowObject = glfwCreateWindow(
        1280, 768,
        "- LotteryDraw -", CreateFlag, nullptr
    );

    // create context.
    glfwMakeContextCurrent(WindowObject);
    // Enable Async. 开启垂直同步.
    glfwSwapInterval(1);

    {
        IMGUI_CHECKVERSION();

        // setup imgui context.
        ImGui::CreateContext();
        ImGuiIO& GuiIO = ImGui::GetIO();

        // 启用 键盘&手柄 交互.
        GuiIO.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard; // enable keyboard controls.
        GuiIO.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;  // enable gamepad controls.

        // setup imgui style.
        ImGui::StyleColorsDark();
        {
            ImGuiStyle* config_style = &ImGui::GetStyle();
            config_style->WindowRounding = 7.2f;
        }

        // init set fonts.
        auto SetFonts = ImGui::GetIO().Fonts;
        SetFonts->AddFontFromFileTTF
        (
            "external_library/guiimgui_library/imgui_fonts/MSYH_Bold.ttf",
            18.0f,
            NULL,
            SetFonts->GetGlyphRangesChineseFull()
        );

        // setup platform & renderer backends.
        ImGui_ImplGlfw_InitForOpenGL(WindowObject, true);
        ImGui_ImplOpenGL3_Init("#version 330 core");
    }

    // main => oglwindow_eventloop
    oglwindow_eventloop(WindowObject);

    // opengl free window.
    glfwDestroyWindow(WindowObject);
    glfwTerminate();
}